function [uwb_out, uwb_error] = UWB_location(p, uwb_err, baseP)
    % p: 目标在三维空间中的真实位置，格式为 [x1, y1, z1; x2, y2, z2; ...]
    % err: 定位误差，用于模拟定位过程中的噪声
    % baseP: 基站位置，格式为 [x1, y1, z1; x2, y2, z2; ...]
    % 计算目标到基站的距离矩阵
    X_ = p(:,1);
    Y_ = p(:,2);
    Z_ = p(:,3);
    baseX_ = baseP(:,1);
    baseY_ = baseP(:,2);
    baseZ_ = zeros(5,1);%基站都放在地上，z=0
    baseR_ = zeros(5,1);   
    R = zeros(length(X_), length(baseX_));
    for i = 1:length(X_)
        for j = 1:length(baseX_)
            R(i, j) = sqrt((X_(i) - baseX_(j)).^2 + (Y_(i) - baseY_(j)).^2 + (Z_(i) - baseZ_(j)).^2);
        end
    end
    R_ = R(:);
    baseR_ = R_;
    
    % 创建stations矩阵,通过intersection_Area函数判断LOS基站
    stations = [baseX_,baseY_,baseR_];
    threshold = 100;
    losStations = intersection_Area(stations,threshold);
    baseX_los = losStations.location(:,1);
    baseY_los = losStations.location(:,2);
    baseZ_los = baseZ_;
    
    % 计算信号传播时间
    time = losStations.r / (3e8); % 光速
    
    % 添加定位误差
    noise_time = randn(size(time));
    time_actually = time + uwb_err * noise_time;
    
    % 计算计算出的距离矩阵
    c = 3e8;
    R_calcu = time_actually * c;
    
    % 构建线性方程組的矩陣H
    H = [
        baseX_los(2) - baseX_los(1), baseY_los(2) - baseY_los(1), baseZ_los(2) - baseZ_los(1);
        baseX_los(3) - baseX_los(1), baseY_los(3) - baseY_los(1), baseZ_los(3) - baseZ_los(1);
        baseX_los(4) - baseX_los(1), baseY_los(4) - baseY_los(1), baseZ_los(4) - baseZ_los(1);
    ];

    % 解线性方程组得到目标位置
    uwb_out = zeros(size(p));
    uwb_error = zeros(size(p, 1), 1);
    
    for i = 1:size(p, 1)
        %a = [sum((baseX_los(2) - baseX_los(1)).^2 + (baseY_los(2) - baseY_los(1)).^2 + (baseZ_los(2) - baseZ_los(1)).^2);
             %sum((baseX_los(3) - baseX_los(1)).^2 + (baseY_los(3) - baseY_los(1)).^2 + (baseZ_los(3) - baseZ_los(1)).^2);
             %sum((baseX_los(4) - baseX_los(1)).^2 + (baseY_los(4) - baseY_los(1)).^2 + (baseZ_los(4) - baseZ_los(1)).^2)];
        distances = c .*time_actually;
        
        % 初始化定位问题的系数矩阵 A 和常数项 b
       A = [];
       b = [];
       
% 对于每个LOS基站，构建一个线性方程
    for j = 1:length(baseX_los)
    % 计算从基站到目标点的距离
    distance = sqrt((baseX_los(j) - p(i, 1))^2 + (baseY_los(j) - p(i, 2))^2 + (baseZ_los(j) - p(i, 3))^2);
    
    % 由于距离是非线性的，使用距离的平方来线性化方程
    distance_squared = distance^2;
    
    % 添加到系数矩阵 A 和常数项向量 b
    A = [A; 2 * (baseX_los(j) - p(i, 1)), 2 * (baseY_los(j) - p(i, 2)), 2 * (baseZ_los(j) - p(i, 3))];
    b = [b; -distance_squared];
    end
    end
    
    
% 使用最小二乘法求解线性系统 Ax = b
uwb_out(i, :) = (A' * A) \ (A' * b);
% 计算定位误差
uwb_error(i) = sqrt(sum((uwb_out(i, :) - p(i, :)) .^ 2));
    % 输出误差统计信息
    %disp(['平均误差: ', num2str(mean(uwb_error))]);
    %disp(['最大误差: ', num2str(max(uwb_error))]);
    %disp(['最小误差: ', num2str(min(uwb_error))]);
    % 绘制三维图
    %fig3D(p, p_out, baseP);
    % 绘制误差分析图
    %figErrorWithErrorBar(error);
end
function fig3D(p, p_out, baseP)
    figure;
    plot3(p(:,1), p(:,2), p(:,3), 'go', 'DisplayName', 'Ideal Position'); % 绘制理想位置
    hold on;
    plot3(p_out(:,1), p_out(:,2), p_out(:,3), 'rx', 'DisplayName', 'Calculated Position'); % 绘制计算位置
    xlabel('X');
    ylabel('Y');
    zlabel('Z');
    title('3D UWB Location');
    grid on;
    hold off; % 添加hold on和hold off来确保数据不会被覆盖

    % 在地图中绘制基站位置三角形
    hold on;
    plot3(baseP(:,1), baseP(:,2), baseP(:,3), 'bv', 'MarkerFaceColor', 'b', 'DisplayName', 'Base Station');
    hold off;
end
function figErrorWithErrorBar(error)
    figure;
    x = 1:length(error);
    errorbar(x, error, 'o');
    xlabel('Target Index');
    ylabel('Error');
    title('UWB Location Error Analysis');
    grid on;
end