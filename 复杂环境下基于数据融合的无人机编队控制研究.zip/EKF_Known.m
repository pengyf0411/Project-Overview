%% 清空工作区
clc; 
clear; 
close all; 

%% Include Folders
addpath("extras\");

%% 加载State_functions
load("C:\Users\Administrator\Desktop\Introduction\3D-EKF-UAV-main\extras\State_functions");

%% 导入仿真参数
sim_parameters; 

%% UWB基站位置
baseP = [0,0,-10;-10,-10,-10;10,10,-10;10,-10,-10;-10,10,-10];%设置五个基站

%% 期望轨迹
disp("Available Trajectories: 8, (c)ircle, (s)piral")
destraj = input("Enter the Trajectory: ", "s"); 
despos0 = [0; 0; 0; pi/2]; 
ydes = trajectory_funs(destraj,despos0); 

%% 加载Landmarks
load("lmk_data");
lmk_data = load("lmk_data");%加载标识点的坐标

%% 初始化
a = zeros(12, 1);    % 初始化真实状态
xhat = zeros(9, 1);  % A当前的状态估计
Phat = diag([0.01 * ones(3, 1); 0.01 * ones(3, 1); 0.02 * ones(3, 1)]);%当前的状态估计协方差
q = [0.01 * ones(3, 1); 0.01 * ones(3, 1); 0.02 * ones(3, 1)]; 
Q = diag(q.^2); 

%% 存储变量
n_a = 12;       % UAV状态变量数量
n_s = 9;        % UAV估计状态变量数量
a_his = NaN(n_a, tsteps); %存储所有时间步长上的真实状态历史数据
a_d_his = NaN(n_a, tsteps); %存储每个时间步长上的真实状态偏差历史数据
ahat_his = NaN(n_a, tsteps);%存储所有时间步长上的估计状态历史数据
u_his = NaN(4, tsteps); %控制输入历史数据
lambda_his = NaN(4, tsteps); 
err_s_his = NaN(n_s, tsteps); %每个时间步长上的估计状态误差历史数据
sigma3_s_his = NaN(n_s, tsteps); %存储每个时间步长上的估计状态的协方差或标准差历史数据
Lo_his = struct("O",[],"y_o",[],"n_o",[],"N_L",[]); 


for i = 1:tsteps
    ti = tspan(i)
    tcomp = tspan(1:i);
    tic;

    %% 真实状态分离
    rho = a(1:3); 
    uav_p = rho.';%无人机真实位置
    nu = a(4:6); 
    Lambda = a(7:9); 
    omega = a(10:12); 
    psi = Lambda(3); 
    %% IMU Sensor Estimates After Noise Filtering
    eta = normrnd(zeros(4,1), sigma_imu);   % Estimation Error 
    if i == 1
        az_hat = - g + eta(1);          % Vertical Accelerometer Estimate
        omega_hat = omega + eta(2:4);   % Gyro Estimate
    else
        az_hat = - (u(1) / m) + eta(1);   % Vertical Accelerometer Estimate
        omega_hat = omega + eta(2:4);   % Gyro Estimate
    end
    lambda = [az_hat; omega_hat];          % Measurements serving as control for SLAM

    %% LiDAR观测
    C_NB = C_NB_fun(Lambda);                %将地理坐标系转换到机体坐标系
    B_L = C_NB' * (N_L - rho);              % 转换后的LiDAR观测值，机体坐标系中的笛卡尔坐标
    Lo = observed_lmks(Lids, B_L, ...
        alpha_lim, beta_lim, delta_lim) ;  
    Lo.N_L = N_L(:,Lo.O);                 % 观测到的地标坐标
    
    v = normrnd(zeros(3, Lo.n_o), repmat(sigma_zeta,1, Lo.n_o)); 
    Lo.y_o = Lo.y_o + v; 
    
    %% UWB定位
     uwb_err = 0.5;
    [uwb_out,uwb_error] = UWB_location(uav_p,uwb_err,baseP);
    
    %% EKF (从i > 1开始)
    if i > 1
        % 预测步: (xhat+, Phat+)_i-1 --> (xhat-, Phat-)_i
        [xhat, Phat, Fi] = predict_known(tspan(i-1), dt, prop_it,...
            sys, xhat, Phat, lambda, f_s, F, G_q, R_imu, Q, Pdot_ss); 

        % 更新步: (xhat-, Phat-)_i --> (xhat+, Phat+)_i
        [xhat, Phat, Hi] = update_known(xhat, Phat,...
            Lo, h_o, H_s, R_zeta,uwb_out); 
    end

    %% 估计状态分离
    rho_hat = xhat(1:3); 
    nu_hat = xhat(4:6); 
    Lambda_hat = xhat(7:9); 
    psi_hat = Lambda_hat(3); 

    %% 轨迹控制
    ahat = [rho_hat; nu_hat; Lambda_hat; omega_hat];
    [u, a_d] = Trajectory_Control(ti, sys, ahat, ydes, A, B, C_NB_fun); 

    %% Check Time of EKF
    dt_es = toc;
    if dt_es >= dt && i > 10
        break;
    end

    %% 存储真实历史状态
    a_his(:, i) = a; 
    a_d_his(:, i) = a_d;
    ahat_his(:, i) = ahat;
    u_his(:, i) = u;
    lambda_his(:, i) = lambda;
    err_s_his(:,i) = ahat_his(1:9, i) - a_his(1:9, i);
    sigma3_s_his(:,i) = 3 .* sqrt(diag(Phat));
    Lo_his(i) = Lo;

    %% 模拟下一时间步的真实状态
    [~, a_ode] = ode45(f_a, ti:h:ti+dt, a, [], u, sys); 
    a = a_ode(end,:)'; 
    %对角状态进行包裹处理，确保角度在[-pi, pi)范围内
    a(7) = pi2pi(a(7), a_his(7,i)); %x
    a(8) = pi2pi(a(8), a_his(8,i)); %y
    a(9) = pi2pi(a(9), a_his(9,i)); %z
    
    %% 检查估计误差
    if any(isnan(err_s_his(:,i)),"all") || mean(abs(err_s_his(1:3,i))) >= 2
%         break;
    end

end

%% 处理时间范围、保存路径设置、可视化参数配置
tcompx = tcomp(tcomp >= 0 & tcomp <= ti); 
fig_path = "results/Known_" + destraj;
vid_path = "videos/Known_" + destraj;
varstr(1) = struct("name", "_pos", "val", 1:3);
varstr(2) = struct("name", "_vel", "val", 4:6);
varstr(3) = struct("name", "_att", "val", 7:9);
varstr(4) = struct("name", "_angr", "val", 10:12);
set(0, 'DefaultLineLineWidth', 0.8);
vis = "on";

%% 作图&动画
Plotting_known;