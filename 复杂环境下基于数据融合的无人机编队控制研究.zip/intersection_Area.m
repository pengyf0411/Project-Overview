function [losStations] = intersection_Area(stations,thresholds)
 % stations: Mx2矩阵，表示M个基站的(x, y)坐标
 % thresholds: 阈值，用于判断LOS
 % nlosStations: 逻辑数组，表示每个基站是否为NLOS
 %% 初始化LOS基站位置，4*2的零数组
 losStations.id = false(5,1);
 losStations.location = zeros(4,2);
 losStations.r = zeros(4,1);
 %% 计算所有基站组合的交叉面积
 for i = 1:size(stations,1)
     for j = i+1:size(stations,1)
         for k = j+1:size(stations,1)
             for l = k+1:size(stations,1)
             %提取当前三个基站的坐标
             station1 = stations(i,:);
             station2 = stations(j,:);
             station3 = stations(k,:);
             station4 = stations(l,:);
           %% 计算四个圆的交叉面积
             % 先计算两个圆的交叉面积
             area12 = calculateTriangleArea(station1,station2);
             area13 = calculateTriangleArea(station1,station3);
             area14 = calculateTriangleArea(station1,station4);
             area23 = calculateTriangleArea(station2,station3);
             area24 = calculateTriangleArea(station2,station4);
             area34 = calculateTriangleArea(station3,station4);
             %取平均值作为三个圆的交叉面积
             area123 = (area12 + area13 + area23)/3;
             area124 = (area12 + area14 + area24)/3;
             area234 = (area23 + area24 + area34)/3;
             %取平均值作为四个圆的交叉面积
             area = (area123 + area124 + area234)/3;
             %判断是否为LOS
             if area < thresholds
                 losStations.id(i) = true;
                 losStations.id(j) = true;
                 losStations.id(k) = true;
                 losStations.id(l) = true;
                 losStations.location(1,:) = station1(1:2);
                 losStations.location(2,:) = station2(1:2);
                 losStations.location(3,:) = station3(1:2);
                 losStations.location(4,:) = station4(1:2);
                 losStations.r(1,1) = station1(3);
                 losStations.r(2,1) = station2(3);
                 losStations.r(3,1) = station3(3);
                 losStations.r(4,1) = station4(3);
                 % 输出信息
                 %fprintf(['基站%d、%d、%d',i,j,k,'是视距基站。']);
                 %disp(['交集面积为：',num2str(area)]);
             end
             end
         end
     end
 end
end
function area = calculateTriangleArea(circle1,circle2)
%计算两个圆的交叉面积
%p1,p2：两个基站
%area:交叉面积
%计算圆心之间距离
d = sqrt((circle1(1) - circle2(1))^2 + (circle1(2) - circle2(2))^2);

%计算两圆半径之和和差
rSum = circle1(3) + circle2(3);
rDiff = abs(circle1(3) - circle2(3));

%判断两圆的位置关系
if d >= rSum %两圆相离或相切
    area = 0;
elseif d < rSum %两圆相交
    %计算两圆相交部分的面积
    a = (circle1(3) * circle2(3) * (d^2 + rDiff^2 - rSum^2)) / (2 * d); 
    area = 2* sqrt(a * (a - circle1(3)^2) * (a - circle2(3)^2));
end
end