% 定义基站位置
stations = [0 0 0; 1 0 0; 1 1 0]; % 四个基站位于三维空间的四个顶点

% 定义球的半径
radius = 1; % 假设每个球的半径为1

% 创建三维图形
figure;
hold on;

% 绘制四个球
for i = 1:size(stations, 1)
    [x, y, z] = sphere(50); % 使用sphere函数生成球面网格
    s = surface(x * radius + stations(i, 1), y * radius + stations(i, 2), z * radius + stations(i, 3), 'FaceAlpha', 0.2, 'EdgeColor', 'none');
end

% 绘制基站位置
plot3(stations(:,1), stations(:,2), stations(:,3), 'r*', 'MarkerSize', 10);

% 添加z=0的平面
[X, Y] = meshgrid(linspace(-1.5, 1.5, 10), linspace(-1.5, 1.5, 10));
Z = zeros(size(X)); % 创建z=0的平面
surf(X, Y, Z, 'FaceColor', 'none', 'EdgeColor', 'k');

% 设置坐标轴属性
axis equal;
grid on;
xlabel('X');
ylabel('Y');
zlabel('Z');

% 添加标题和图例
title('四个UWB基站的球体表示与z=0平面');
%legend('基站', '球体', 'z=0平面');

% 设置视图
view(3);
axis tight; % 使坐标轴紧凑，以适应所有球体
daspect([1, 1, 1]); % 设置坐标轴的纵横比为1:1:1

% 保持图形
hold off;
shading interp; % 平滑着色