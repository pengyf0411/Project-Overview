function Animation(tseq, a_his, a_d_his, ahat_his, Lids, N_L, Lo_his,...
    alpha_lim, beta_lim, delta_lim, vid_path,baseP)
%蓝色轨迹代表真实轨迹
%黑色轨迹代表估计轨迹
%红色轨迹代表期望轨迹
VIDEO = false;
if VIDEO
    video = VideoWriter(vid_path, 'Motion JPEG AVI');
    video.FrameRate = 30;
    video.Quality = 95;
    open(video);
end

%% Plot Landmarks
% baseP_hat = baseP.';
scatter3(N_L(2, :), N_L(1, :), -N_L(3, :), 50, 'bo',...
    'DisplayName', 'True Landmarks'); % True Landmarks
hold on;
for i = 1:size(baseP, 1)
     scatter3(baseP(i, 1), baseP(i, 2), baseP(i, 3), 100,...
         'r^', 'DisplayName', sprintf('UWB base %d', i));
end
% scatter3(baseP_hat(1,:), baseP_hat(2,:), baseP_hat(3,:), baseP_hat(4,:),...
%     baseP_hat(5,:), 100, 'r^', 'DisplayName', 'UWBbase');%绘制UWB基站
%% Plot trajectory
xlabel('North', "FontName", "times")
ylabel('East', "FontName", "times")
zlabel('Up', "FontName", "times")
axis('equal')
view(-37.5, 30)
hold on
grid on
xlim([-10, 10])
ylim([-10, 10])
zlim([-10, 10])
rotate3d on
if size(N_L, 2) <= 30
    text(N_L(2, :), N_L(1, :), -N_L(3, :), string(Lids));
end

ahat_his2 = ahat_his;%复制估计轨迹
ahat_his2(3,:) = ahat_his(3,:)+5;
a_his2 = a_his;%复制真实轨迹
a_his2(3,:) = a_his(3,:)+5;
a_d_his2 = a_d_his;%复制期望轨迹
a_d_his2(3,:) = a_d_his(3,:)+5;


for i = tseq
    % Quad 1 Estimated
    quad1 = Draw_Quad(ahat_his(7, i), -ahat_his(8, i), ...
        pi/2 - ahat_his(9, i), ahat_his(2, i), ahat_his(1, i),...
        - ahat_his(3, i), 'k--', 0.3);
    quad1_traj = plot3(ahat_his(2, 1:i), ahat_his(1, 1:i), ...
        -(ahat_his(3, 1:i)), '--', 'DisplayName',...
        'Estimated Trajectory');
    quad1_traj.Color = 'k'; % Estimated Trajectory

     % Quad 2 Estimated
     quad2 = Draw_Quad(ahat_his2(7, i), -ahat_his2(8, i), ...
         pi/2 - ahat_his2(9, i), ahat_his2(2, i), ahat_his2(1, i),...
         - ahat_his2(3, i), 'k--', 0.3);
     quad2_traj = plot3(ahat_his2(2, 1:i), ahat_his2(1, 1:i), ...
         -(ahat_his2(3, 1:i)), '--');
    
    % Quad1 True
    quad1_true = Draw_Quad(a_his(7, i), -a_his(8, i), ...
        pi/2 - a_his(9, i), a_his(2, i), a_his(1, i),...
        -a_his(3, i), 'b-', 1); 
    quad1_true_traj = plot3(a_his(2, 1:i), a_his(1, 1:i), ...
        -(a_his(3, 1:i)), '-',  'DisplayName',...
        'True Trajectory');
    quad1_true_traj.Color = 'b'; % True Trajectory
    
    % Quad2 True
    quad2_true = Draw_Quad(a_his2(7, i), -a_his2(8, i), ...
        pi/2 - a_his2(9, i), a_his2(2, i), a_his2(1, i),...
        -a_his2(3, i), 'b-', 1); 
    quad2_true_traj = plot3(a_his2(2, 1:i), a_his2(1, 1:i), ...
        -(a_his2(3, 1:i)), '-');
    quad2_true_traj.Color = 'b'; % True Trajectory
    
    % Quad1 Desired Trajectory
    traj1 = plot3(a_d_his(2, 1:i), a_d_his(1, 1:i), -(a_d_his(3, 1:i)),...
        '-.',  'DisplayName', 'Desired Trajectory');
    traj1.Color = 'r'; % Desired Trajectory
    
    % Quad2 Desired Trajectory
    traj2 = plot3(a_d_his2(2, 1:i), a_d_his2(1, 1:i), -(a_d_his2(3, 1:i)),...
        '-.');
    traj2.Color = 'r'; % Desired Trajectory

    % Observed Landmarks
    L_o_lmks = scatter3(Lo_his(i).N_L(2, :), Lo_his(i).N_L(1, :), ...
        -Lo_his(i).N_L(3, :), 50, 'm*', 'DisplayName', 'Observed Landmarks');

    % FOV1 Generation
    [fov1_X, fov1_Y, fov1_Z] = fov_3D_rec(alpha_lim(2), beta_lim(2), delta_lim);
    M = makehgtform('translate', [a_his([2, 1], i);-a_his(3, i)], ...
        'zrotate', pi/2-a_his(9, i), 'yrotate', -a_his(8, i), ...
        'xrotate', a_his(7, i));
    fov1 = surf(fov1_X, fov1_Y, fov1_Z, 'Parent', hgtransform('Matrix', M), ...
        'LineStyle', 'none', 'FaceAlpha', 0.1);
    
    %FOV2 Generation
    [fov2_X, fov2_Y, fov2_Z] = fov_3D_rec(alpha_lim(2), beta_lim(2), delta_lim);
    M = makehgtform('translate', [a_his2([2, 1], i);-a_his2(3, i)], ...
        'zrotate', pi/2-a_his2(9, i), 'yrotate', -a_his2(8, i), ...
        'xrotate', a_his2(7, i));
    fov2 = surf(fov2_X, fov2_Y, fov2_Z, 'Parent', hgtransform('Matrix', M), ...
        'LineStyle', 'none', 'FaceAlpha', 0.1);

    % Legend
    leg = [];
    h = findobj(gca,{'DisplayName', 'True Landmarks', '-or',...
                    'DisplayName','Observed Landmarks', '-or', ...
                    'DisplayName', 'True Trajectory', '-or', ...
                    'DisplayName','Estimated Trajectory', '-or', ...
                    'DisplayName', 'Desired Trajectory','-or',...
                    'DisplayName','UWB base'});
                
    leg = legend(h, 'FontName', 'times', "FontSize", 12);
    leg.Location = 'northeast';

    set(gca, 'fontname', 'times', "FontSize", 12)

    % Creating animation
    drawnow limitrate;
    if VIDEO
        frame = getframe(gcf);
        writeVideo(video, frame);
    end

    handles2del1 = [quad1; quad1_traj; quad1_true; quad1_true_traj; traj1;...
                L_o_lmks; fov1; leg];
    handles2del2 = [quad2; quad2_traj; quad2_true; quad2_true_traj; traj2;...
                L_o_lmks; fov2; leg];
            
    if i<tseq(end)
        delete(handles2del1);
        delete(handles2del2);
    else
        delete(quad1);
        delete(quad2);
    end
    
end