function [xhat, Phat, Fi] = predict_known(ti, dt, prop_it, sys, xhat, ...
    Phat, u_s, f_s, F, G_q, R_imu, Q, Pdot_ss)
% ti: 当前时间步。
% dt: 时间步长。
% prop_it: 传播迭代次数，用于在每个时间步内进行多次状态传播以提高仿真精度。
% sys: 系统参数，可能包括重力加速度g、无人机质量m和转动惯量J_vec。
% xhat: 当前状态估计向量，包含位置、速度、姿态角和角速度等。
% Phat: 当前状态估计的协方差矩阵。
% u_s: 控制输入向量，可能包括期望的推力和姿态控制。
% f_s: 状态函数，定义了无人机的动力学模型。
% F: 状态雅可比矩阵，用于线性化动力学模型。
% G_q: 过程噪声雅可比矩阵。
% R_imu: IMU传感器的测量误差协方差矩阵。
% Q: 过程噪声协方差矩阵。
% Pdot_ss: 协方差矩阵的传播函数。

h = dt / prop_it;%通过将时间步长 dt 除以迭代次数 prop_it 来计算每个迭代的子时间步长
shat = xhat(1:9);% xhat 中提取前9个元素作为当前的状态向量。

%% Propagation / Prediction xhat
Fi  = F(ti, shat, u_s, sys);%计算预测模型

[~, shat_ode] = ode45(f_s, ti:h:ti+dt, shat, [], u_s, sys);%对状态函数f_s进行数值积分，
                                                           %从当前时间 ti 开始，以 h 为步长，直到 ti+dt。这将预测下一个时间步长的状态 shat_ode
xhat(1:9) = shat_ode(end, :)';%更新状态

%% Propagation / Prediction Phat
for i = 1:prop_it
    [ti, Phat] = RK4_Phat_ss(Pdot_ss, ti, Phat, Fi, Q, h);%四阶Runge-Kutta方法来数值求解非线性系统的微分方程
end