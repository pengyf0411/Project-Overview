function [xhat, Phat, Hi] = update_known(xhat, Phat, Lo, h_o, H_s, R_zeta,uwb_out)
% xhat: 当前的状态估计向量。
% Phat: 当前状态估计的协方差矩阵。
% Lo: 观测到的地标数据，包括观测到的地标位置y_o和观测到的地标数量n_o。
% h_o: 观测模型函数，用于从当前状态估计生成观测。
% H_s: 观测模型的雅可比矩阵。
% R_zeta: 观测噪声协方差矩阵。

% xhat: 更新后的状态估计向量。
% Phat: 更新后的协方差矩阵。
% Hi: 更新步骤中使用的观测模型雅可比矩阵的局部值。

n_s = 9;            % 状态数量=9
shat = xhat(1:n_s); % 提取前9个元素

y_o = Lo.y_o(:); 
n_o = Lo.n_o;
N_L = Lo.N_L;
Hi = NaN(numel(y_o), size(xhat,1));
ho_k = NaN(size(y_o));
R_zeta_k = zeros(numel(y_o), numel(y_o));


%% Lump Update
% K是卡尔曼增益，用于最小化误差协方差矩阵E
% Z是更新步骤中的残差，它是观测值和由当前状态估计生成的观测值之间的差异。
if ~isempty(N_L)
    for k = 1:n_o
        l = N_L(:,k); % Known Lmks
        loc = (3 * k - 2) : (3 * k);
        Hi(loc, :) = H_s(shat, l); %雅可比矩阵Hi
        ho_k(loc, :) = h_o(shat, l); %观测向量
        R_zeta_k(loc, loc) = R_zeta;
    end
E = R_zeta_k + (Hi * Phat * Hi');
K = Phat * Hi' / E;
Z = y_o - ho_k;
xhat = xhat + K * Z;
Phat = Phat - K * E * K';
end